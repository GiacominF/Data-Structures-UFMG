#include "sort.h"

void shellSort(int *A, int n, sortperf_t * s) {
    printf("Chamando shellsort\n");
    inccalls(s,1);
    for(int h = n/2; h > 0; h /= 2) {
        for (int i = h; i < n; i++) {
            int temp = A[i];
            int j;
            for (j = i; j >= h && A[j-h] > temp; j -= h) {
                inccmp(s,2);
                A[j] = A[j-h];
            }
            A[j] = temp;
        }
    }
}

void recursiveSelectionSort(int arr[], int l, int r, sortperf_t * s) {
    int min = l;
    inccalls(s,1);
    for (int j = l + 1; j <= r; j++) {
        inccmp(s,1);
        if (arr[j] < arr[min]) {
            min = j;
        }
    }
    if (min != l)
        swap(&arr[min], &arr[l], s);

    if (l + 1 < r) {
        recursiveSelectionSort(arr, l + 1, r, s);
    }
}

void selectionSort(int arr[], int l, int r, sortperf_t *s) {  
    inccalls(s, 1);
    int min;

    for (int i = l + 1; l < r - 1; i++) {  // Correção no índice
        min = i;

        for (int j = i + 1; j < r; j++) {
            inccmp(s, 1);
            if (arr[j] < arr[min]) {
                min = j;
            }
        }

        if (min != i) {  
            swap(&arr[i], &arr[min], s);  
        }
    }
}


void insertionSort(int v[], int l, int r, sortperf_t * s) {

    int aux, j;
    for (int i = l; i < r; i++) {
        aux = v[i];
        j = i - 1;

        while((j >= l) && (aux < v[j])) {
            inccmp(s,1);
            v[j + 1] = v[j];
            incmove(s,1);
            j--;
        }
        v[j + 1] = aux;
        incmove(s,1);
    }

  return;
}

int median (int a, int b, int c) {
    if ((a <= b) && (b <= c)) return b;
    if ((a <= c) && (c <= b)) return c;
    if ((b <= a) && (a <= c)) return a;
    if ((b <= c) && (c <= a)) return c;
    if ((c <= a) && (a <= b)) return a;
    return b;
}

void partition3(int * A, int l, int r, int *i, int *j, sortperf_t *s) {
}

void partition(int * A, int l, int r, int *i, int *j, sortperf_t *s) {
}

void quickSort(int * A, int l, int r, sortperf_t *s) { 
}

void quickSort3(int * A, int l, int r, sortperf_t *s) { 
}

void quickSortIns(int * A, int l, int r, sortperf_t *s) { 
}

void quickSort3Ins(int * A, int l, int r, sortperf_t *s) { 
}
