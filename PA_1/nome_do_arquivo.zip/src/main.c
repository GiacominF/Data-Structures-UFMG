#include "sort.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <time.h>

int main(int argc, char ** argv) {
    sortperf_t s;
    int * vet;
    char buf[200];
    char pref[100];
    opt_t opt;
    struct timespec inittp, endtp, restp;
    int retp;

    parse_args(argc, argv, &opt);
    vet = (int *) malloc((opt.size+1) * sizeof(int));

    resetcounter(&s);
    srand48(opt.seed);
    initVector(vet, opt.size);
    vet[opt.size] = vet[0];

    retp = clock_gettime(CLOCK_MONOTONIC, &inittp);
    
    switch (opt.alg){
        case ALGINSERTION:
             insertionSort(vet, 0, opt.size-1, &s);
             break;
        case ALGSELECTION:
             selectionSort(vet, 0, opt.size-1, &s);
             break;
        case ALGQSORT:
             quickSort(vet, 0, opt.size-1, &s);
             break;
        case ALGQSORT3:
             quickSort3(vet, 0, opt.size-1, &s);
             break;
        case ALGQSORTINS:
             quickSortIns(vet, 0, opt.size-1, &s);
             break;
        case ALGQSORT3INS:
             quickSort3Ins(vet, 0, opt.size-1, &s);
             break;
        case ALGSHELLSORT:
             shellSort(vet, opt.size, &s);
             break;
        case ALGRECSEL:
             recursiveSelectionSort(vet, 0, opt.size-1, &s);
             break;
    }
    
    retp = clock_gettime(CLOCK_MONOTONIC, &endtp);
    clkDiff(inittp, endtp, &restp);

    sprintf(pref, "alg %s seed %d size %d time %ld.%.9ld",
            num2name(opt.alg), opt.seed, opt.size, restp.tv_sec, restp.tv_nsec);

    printsortperf(&s, buf, pref);
    printf("%s\n", buf);

    exit(0);
}
